import java.Scanner;
import java.io.File;
import java.io.FileNotFoundExeption;


public class Main {
	public static void main(String[] args) throws FileNotFoundExeption{
	
		String input = "";
		int T = 0;
		String name[] = new String [2];
		
		File f = new File ("input.in");
		Scanner dataIn = new Scanner (f);
		
		int n = dataIn.nextLine();
		T = Integer.parseInt (n);
		
		for (i=0; i<T; i++);
		
		int n = dataIn.nextLine();
		name = dataIn.split ("", 2);
		
		if(name[0].substring(0,3).equals(name[1].substring (0,3)))
		   System.out.println("YES");
		   
 	  else
 	      System.out.println("NO");
					
							
	}
}