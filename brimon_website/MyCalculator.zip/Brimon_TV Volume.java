import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Brimon_TV Volume {
	public static void main(String[] args) throws FileNotFoundException{
		
		String input= "";
		int initialVol, finalVol;
		File f = new File ("./Root/src/input.in");
		Scanner dataIn = new Scanner (f);
		int n = dataIn. nextInt();
		   for (int x=0; x<n; ++x){
		   int X = dataIn.nextInt();
		   int Y = dataIn.nextInt();
	if (X > Y){
		System.out.println(X - Y);
	}
	
    else{
    	System.out.println(Y - X);
    }
    
   	}	
	}
}