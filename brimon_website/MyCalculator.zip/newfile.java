import java.io.File;
import java.IOExeption;
import java.util.Scanner;
import java.io.FileNotFoundExeption;


class Main {
	public static void main(String[] args) throws FileNotFoundExeption{
		String data_1="";
		String Values[] = new String [2];
		int iniVol, finVol;
		File input= new file ("./Root/src/input.in");
		Scanner myReader = new Scanner (input);
		     while (myReader.hasNextLine()){
		        data_1 = (myReader.nextLine());
		        int test_case = Integer.parseInt(data_1);
		        for (int x=0; x<test_case; ++x){
		           data_1 = (myReader.nexLline);
		           values = data_1.split("", 2);
		           iniVol = Integer.parseInt(values[0]);
		           finVol = Integer.parseInt(values[1]);
		        if (iniVol>finVol){
		        	System.out.println ((iniVol - finVol));
		        }
		        else {
		            System.out.println ((finVol - iniVol));	
		       }
		     }
		  }
		  myReader.close();
		
  	}
 }