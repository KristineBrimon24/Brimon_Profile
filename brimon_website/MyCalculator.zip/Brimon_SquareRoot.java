public class SquareRoot
{
    public static void main(String args[])
    {
        double num = Double.parseDouble(args[0]);
        double temp;
        double sr = num/2;

        do{
           temp = sr;
           sr = (temp+(num/temp))/2;
        }
            while ((temp - sr ) !=0);
            System.out.println(" The Square root of" + num + " is " + sr);
    }
}
