import java.io.*;
import java.util.*;

public class BRIMON_MultiDimensionalArray {
    public static void main(String[] args) {
        // 10 dimensional array size of 3x2x2x2x2x2x2x2x2x2x2
        int num [][][][][][][][][][] = new int[3][2][2][2][2][2][2][2][2][2];
        int count = 0;

        for (int a = 0; a < 3; a++) {   //1st dimension
            for (int b = 0; b < 2; b++) {   //2nd dimension
                for (int c = 0; c < 2; c++) {   //3rd dimension
                    for (int d = 0; d < 2; d++) {   //4th dimension
                        for (int e = 0; e < 2; e++) {   //5th dimension
                            for (int f = 0; f < 2; f++) {   //6th dimension
                                for (int g = 0; g < 2; g++) {   //7th dimension
                                    for (int h = 0; h < 2; h++) {   //8th fimension
                                        for (int i = 0; i < 2; i++) {   //9th dimension
                                            for (int j = 0; j < 2; j++) {    //10th dimension
                                               num [a][b][c][d][e][f][g][h][i][j] = count;
                                                count++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // System.out.println(num[1][0][0][0][0][1][0][0][1][0]);

        for (int a = 0; a < 3; a++) {
            for (int b = 0; b < 2; b++) {
                for (int c = 0; c < 2; c++) {
                    for (int d = 0; d < 2; d++) {
                        for (int e = 0; e < 2; e++) {
                            for (int f = 0; f < 2; f++) {
                                for (int g = 0; g < 2; g++) {
                                    for (int h = 0; h < 2; h++) {
                                        for (int i = 0; i < 2; i++) {
                                            for (int j = 0; j < 2; j++) {
                                            	
            System.out.println(num[a][b][c][d][e][f][g][h][i][j]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}