import java.util.*;
import java.io.*;"

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		
		int T, A, X, B, Y = 0;
		T = A = X = B = Y = 0;
		int result = 0;
		float Total_Value1, Total_Value2;
		
		String Input = " ";
		String value [] = new String [4];
		
		File f = new file ("input.in");
		Scanner dataIn = new Scanner (f);
		
		input = dataIn.nextLine();
		T = Integer.parseInt(input);
		
		for (int i=0; i<T; i++){
			input = dataIn.nextLine();
			value = input.split(" ",4);
			
		A = Integer.parseInt(value[0]);
		X = Integer.parseInt(value[1]);
		Total_Value1 = A/X
		
		B = Integer.parseInt(value[2]);
		Y = Integer.parseInt(value[3]);
		Total_Value2 = B/Y
		
		if (Total_Value1 < Total_Value2){
			System.out.println("Brian")
		}
		 else if (Total_Value1 > Total_Value2){
		 	System.out.println("Dominic")
		 }
		 else 
		     System.out.println("EQUAL");
		}
	}
}